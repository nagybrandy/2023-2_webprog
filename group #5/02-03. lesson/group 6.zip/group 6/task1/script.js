const dec_btn = document.querySelector('#decrease')
const inc_btn = document.querySelector('#increase')
const input = document.querySelector('input')

const MAX = 5
const MIN = -5

input.value = 0

inc_btn.addEventListener('click', () => {
    if(input.value < MAX) {
        input.value++
        dec_btn.disabled = false
    }
    else inc_btn.disabled = true
})

dec_btn.addEventListener('click', () => {
    if(input.value > MIN) {
        input.value--
        inc_btn.disabled = false
    }
    else dec_btn.disabled = true
})