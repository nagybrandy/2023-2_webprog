let faqDiv = document.querySelector('.faq')
function delegate(parent, child, when, what){
    function eventHandler(event){
        let eventTarget = event.target;
        let eventHandler = this;
        let closestMatchingElement = eventTarget.closest(child);

        if(eventHandler.contains(closestMatchingElement)){
            what(event, closestMatchingElement);
        }
    }

    parent.addEventListener(when, eventHandler);
}

delegate(faqDiv, "h2", "click", (e)=> {
    e.target.nextElementSibling.classList.toggle('visible')
    console.log(e.target.nextSibling)
    console.log(e.target.nextElementSibling)
})

// bubbles down into each element
/* faqDiv.addEventListener('click', (e)=> {
    if(e.target.matches('h2')){
        const elem = e.target.nextElementSibling
        elem.classList.toggle('visible')

         if(!elem.classList.contains('visible')) {
            elem.classList.add('visible') 
        } else {
            elem.classList.remove('visible') 
        } 
    }
})
// div > click-h2 > h2.nextSibling (<p>) -> make it visible */