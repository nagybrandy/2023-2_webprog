let list = [
    {
        "country": "Germany",
        "city": "Berlin"
    },
    {
        "country": "Germany",
        "city": "Munich"
    },
    {
        "country": "Germany",
        "city": "Königsberg"
    },
    {
        "country": "France",
        "city": "Paris"
    },
    {
        "country": "United Kingdom",
        "city": "London"
    },
    {
        "country": "United Kingdom",
        "city": "Dublin"
    },
    {
        "country": "United Kingdom",
        "city": "Hong Kong"
    },
    {
        "country": "United Kingdom",
        "city": "Delhi"
    },
    {
        "country": "Austria",
        "city": "Vienna"
    },
    {
        "country": "Austria",
        "city": "Bratislava"
    },
    {
        "country": "Austria",
        "city": "Budapest"
    },
    {
        "country": "Russia",
        "city": "Moscow"
    },
    {
        "country": "Ukraine",
        "city": "Kiev"
    },
    {
        "country": "Russia",
        "city": "Warsaw"
    }
]

document.querySelector('button')
    .addEventListener('click', ()=> {
        document.querySelector('ul').innerHTML = ""
        let filtered = list.filter(e => e.country === document.querySelector('input').value)

        filtered.forEach(e=> {
            document.querySelector('ul').innerHTML += `<li>${e.city}</li>`
        })
   
    })
