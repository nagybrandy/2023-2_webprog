<?php
    $errors = [];
    $data = [];
    $input = $_GET;
    // CREATE VALIDATION LOGIC HERE!
    function validate(&$errors, &$data, $input) {
        // name -> it should exist, length > 0
        
        // quantity -> filter_var()
        return count($errors) === 0;
    }

    // ADD TO THE JSON FILE HERE!
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Food Item Added</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/elte-fi/www-assets@19.10.16/styles/mdss.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Save</title>
</head>
<body>
   
    <!-- Display this if successful -->
    <h1>Successfully added! 😍</h1>
    <a href='index.php'>Back to main page</a>
    
    <!-- Display this if unsuccessful -->
    <h1>Failed to add! 😢😭</h1>
    <a href='addfood.php'>Add new</a>


<?php if ($errors) : ?>
        <ul style="font-size: 25px;color: red;">
        <?php foreach($errors as $error) : ?>
            <li><?= $error ?></li>
            <?php endforeach; ?>
        </ul>
<?php endif; ?>
</body>
</html>
